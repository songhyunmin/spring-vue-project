module.exports={
loaders:[  {
    test: /\.(gif|svg|jpg|png)$/,
    loader: "file-loader",
    }]

}