package vuejs.spring.dto;

import lombok.Data;

@Data
public class MenuDTO {
    private String title;
    private String link;
    private String img;

    public MenuDTO(String title, String link, String img) {
        this.title = title;
        this.link = link;
        this.img = img;
    }
}