package vuejs.spring.repository;

import vuejs.spring.domain.Menu;

import java.util.List;

public interface MenuRepository {
    List<Menu> menuList();
}
