package vuejs.spring.dao;

import vuejs.spring.dto.MenuDTO;

import java.util.List;

public interface MenuDAO {

    List<MenuDTO> menuList();
}