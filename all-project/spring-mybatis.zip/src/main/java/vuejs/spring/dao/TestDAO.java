package vuejs.spring.dao;

import vuejs.spring.dto.TestDTO;
import java.util.List;

public interface TestDAO {

    List<TestDTO> getTestData();
}