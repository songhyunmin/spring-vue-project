<template>
    <div>
      <h4>Copyrights &copy; 디모데교회 All Rights Reserved.<br />Programmed by 스데반정보</h4>
    </div>
</template>

<script>
export default {
  name: "commonfooter"
}
</script>
